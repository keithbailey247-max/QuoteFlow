import Link from 'next/link';
const links=[['/dashboard','Dashboard'],['/rfqs','RFQs'],['/field-surveys','Field Surveys'],['/estimates','Estimates'],['/inventory','Inventory'],['/proposals','Proposals'],['/ask-qf','Ask QuoteFlow']];
export default function Nav(){return <aside className="nav"><div className="brand">QuoteFlow</div>{links.map(([h,l])=><Link key={h} href={h}>{l}</Link>)}</aside>}
