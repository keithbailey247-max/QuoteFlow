import './globals.css'; import Nav from '../components/Nav';
export const metadata={title:'QuoteFlow',description:'AI estimating and proposal intelligence for contractors'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body><div className="shell"><Nav/><main className="main">{children}</main></div></body></html>}
