# QuoteFlow MVP v0.1

QuoteFlow is a multi-tenant AI bid/RFQ/estimating platform for contractors.

## Included
- Responsive Next.js application shell
- Dashboard, RFQs, field surveys, estimates, inventory, proposals
- Ask QuoteFlow to Build It foundation
- PostgreSQL/Prisma multi-tenant schema
- Provenance/confidence/verification records for AI-extracted facts
- Versioned tenant configuration and audit events
- Supplier quote and leftover inventory foundations

## Run locally
1. Install Node.js 20+
2. Copy `.env.example` to `.env`
3. Add a PostgreSQL DATABASE_URL
4. `npm install`
5. `npx prisma generate`
6. `npx prisma migrate dev --name init`
7. `npm run dev`

## Important production work remaining
Authentication/authorization, enforced tenant row-level security, object/file storage, CRUD APIs, AI extraction, supplier communications, proposal PDF generation, tests, observability, backups, billing and deployment.

The OpenAI API is separate from a ChatGPT Plus subscription. Do not place API keys in source control.
